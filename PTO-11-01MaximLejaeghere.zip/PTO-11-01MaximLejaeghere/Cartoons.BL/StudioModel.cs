﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cartoons.BL
{
	public class StudioModel : CartoonModel
	{


		



		//Constructors

		public StudioModel(string studio)
		{

		}

		public StudioModel()
		{

		}

		// Methodes

	}
}
